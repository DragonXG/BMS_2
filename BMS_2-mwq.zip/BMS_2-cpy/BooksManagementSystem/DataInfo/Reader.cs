﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataInfo
{
    //读者信息表
    class Reader
    {
        public String cardName;
        public String readerName;
        public String college;
        public String profession;
        public String telNumber;
        public String loginKey;
    }
}
