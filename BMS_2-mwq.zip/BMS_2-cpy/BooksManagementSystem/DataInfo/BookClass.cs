﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DataInfo
{
    //图书类表
    class BookClass
    {
        public String bookClassId;
        public String bookName;
        public String bookAuthor;
        public String bookPress;
        public String bookSummary;
        public Double bookPrice;
    }
}
