﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataInfo
{
    //管理员信息表
    public class Admin
    {
        public String adminId;
        public String adminName;
        public String telName;
        public String loginName;
        public String loginKey;
        public String addr;
    }
}
