﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataInfo
{
    //预定图书记录表
    class BorrowBook
    {
        public String boolId;
        public String bookName;
        public String cardNum;
        public String bookDate;
    }
}
