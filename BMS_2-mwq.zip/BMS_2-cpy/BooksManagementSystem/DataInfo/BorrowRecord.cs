﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataInfo
{
    //借阅记录表
    class BorrowRecord
    {
        public String boolId;
        public String bookName;
        public String cardNum;
        public String borrowDate;

    }
}
