﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataInfo
{
    //图书信息表
    class BookInfo
    {
        public String bookId;
        public String bookClassId;
        public int sendFlag;
    }
}
